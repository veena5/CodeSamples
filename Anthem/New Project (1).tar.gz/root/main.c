#include <stdio.h>
#include <string.h>
#include <ctype.h>
 
int main()
{
    char sentence[100], words_sentence[20], firstlargest[20], secondlargest[20], characters;
    int i = 0, j = 0, k=0, flag = 0; 
    printf("Enter different words when finished giving your input words press :(colon) and then enter to complete giving the input ");
    i = 0;
    do
    {
        fflush(stdin);
        characters= getchar();
        sentence[i++] = characters;
 
    } while (characters!= ':');  // taking input until the button : is pressed
    sentence[i - 1] = '\0';   
	//iterating the loop for length of sentence times
    for (i = 0; i < strlen(sentence); i++)
    {
        while (i < strlen(sentence) && !isspace(sentence[i]) && isalnum(sentence[i]))
        {
            words_sentence[j++] = sentence[i++];
            
        }       
        if (j != 0)
        {
            words_sentence[j] = '\0';
            if (!flag)
            {
                flag = !flag;
                strcpy(firstlargest, words_sentence);
                strcpy(secondlargest, words_sentence);

            }
            printf("The length of word -- '%s' is '%d'\n", words_sentence, strlen(words_sentence));
			// logic to find first and second highest numbers 
		   if (strlen(words_sentence) > strlen(firstlargest))
            {
                strcpy(secondlargest, firstlargest);
                strcpy(firstlargest, words_sentence);
            }
            else if(strlen(words_sentence) > strlen(secondlargest))
            {
                strcpy(secondlargest, words_sentence);

            }                 
            j = 0;
        }
    }    
    printf("The largest word in the given list of words is '%s' and second largest word is '%s'  \n", firstlargest, secondlargest);
 
    return 0;
}